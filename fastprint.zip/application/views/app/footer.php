<footer class="container-fluid text-center">
  <p>Copyright © 2023 Tugas Test FastPrint (Bismillah Semoga Lolos)</p>
</footer>